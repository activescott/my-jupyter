import os


def env_or_default(env_name, default_value=None):
    if env_name in os.environ is not None:
        return os.environ[env_name]
    return default_value


def env_or_fail(env_name, raise_if_not_found=False, default_value=None):
    if env_name in os.environ is not None:
        return os.environ[env_name]
    if raise_if_not_found:
        raise ValueError(
            f'Setting `{env_name}` must be provided as an OS environment variable.')
    return default_value
